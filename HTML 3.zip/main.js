let lost=false;
let canvas =document.getElementById('main');
let score=0;
let ctx=canvas.getContext('2d');
player={x:0,y:0};
player.x= (Math.floor(Math.random()*4)*120);
player.y=canvas.height-100;
let enemies=new Array();
function makeenemy(){
let a=  (Math.floor(Math.random()*4)*120);
let enemy={
  x:a,
  y:-100
};
enemies.push(enemy);
}
function moveleft(){
  if (player.x != 0) {
    player.x = player.x - 30;
  }
}
function moveright() {
  if(player.x!=canvas.width-50){
  player.x=player.x+30;
  }
  // Tab to edit
}
function collision(){
  for (let i = 0; i < enemies.length; i++) {
    const enemyCar = enemies[i];
  
    if (
      player.y < enemyCar.y + 100 &&
      player.y + 100 > enemyCar.y &&
      player.x < enemyCar.x + 50 &&
      player.x + 50 > enemyCar.x
    ) {
      return true;
    }
  }
  
  return false;
  }
function update() {
  // Tab to edit
  
  ctx.clearRect(0,0,canvas.width,canvas.height);
  
  for (let i=0;i<enemies.length;i++) {
    
    ctx.fillStyle='red';
    ctx.fillRect(enemies[i].x, enemies[i].y, 50, 100);
    enemies[i].y+=10;
    if(enemies[i].y+50>canvas.height){
    enemies.splice(i,1);
    score++;
    document.getElementById("score").innerText='score : '+(score);
    }
   
  
  
  }
    ctx.fillStyle='blue';
  ctx.fillRect(player.x,player.y,50,100);
  if (collision()) {
    ctx.font="20px Arial";
    ctx.fillText("GAME OVER",150,250);
    lost = true;
  
  }
if(!lost){
  requestAnimationFrame(update);
}
  
}
setInterval(()=>{makeenemy()},500)
update();
