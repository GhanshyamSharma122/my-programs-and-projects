
const text=(id)=>{
return document.getElementById(id).value;
}
function graphX(a) {
  return 150+a;
}

function graphY(a) {
  return 150- a;
}
const plotpoint=(x,y)=>{
  x=x-.5;
  y=y-1;
  shyam.ctx.beginPath();
  shyam.ctx.fillStyle='red'
  shyam.ctx.fillRect(x,y,1,1);
  shyam.ctx.fill();
}
const plot= ()=>
{
  x1=Number(text("xrange1"));
x2=Number(text("xrange2"));
  equ=text("eqn");
  for(let a =x1;a<=x2;a+=.1){
    let val1=equ.replaceAll('x',(a));
    console.log(val1);
    let val2=eval(val1);
    if(val2){
      plotpoint(graphX(a),graphY(val2));
    }
  }
}
const plusminus=()=>{
  x1 = Number(text("xrange1"));
  x2 = Number(text("xrange2"));
  equ = text("eqn");
  for (let a = x1; a <= x2; a += .1) {
    let val1 = equ.replaceAll('x', (a));
    console.log(val1);
    let val2 = eval(val1);
    if (val2) {
      plotpoint(graphX(a), graphY(-1*val2));
    }
  }
  
}
const shyam={
canvas:document.getElementById("shyam"),
start:function () {
  this.canvas.width=300;
  this.canvas.height=300;
  this.ctx=this.canvas.getContext('2d');
},
initgraph:function () {
  this.start();
  this.ctx.beginPath();
  this.ctx.moveTo(0, 150);
  this.ctx.lineTo(300, 150);
  this.ctx.stroke();
  this.ctx.beginPath();
 this.ctx.moveTo(150,0);
  this.ctx.lineTo(150, 300);
  // Draw the Path
  this.ctx.stroke();
}

};
shyam.initgraph();



